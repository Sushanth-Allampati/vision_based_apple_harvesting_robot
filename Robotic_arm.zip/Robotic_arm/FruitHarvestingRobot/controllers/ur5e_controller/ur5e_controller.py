from controller import Supervisor
import math
import numpy as np
import csv
import os

# ============================================================
# ROBOT INITIALIZATION
# ============================================================

robot = Supervisor()
timestep = int(robot.getBasicTimeStep())

j1 = robot.getDevice("shoulder_pan_joint")
j2 = robot.getDevice("shoulder_lift_joint")
j3 = robot.getDevice("elbow_joint")
j4 = robot.getDevice("wrist_1_joint")
j5 = robot.getDevice("wrist_2_joint")
j6 = robot.getDevice("wrist_3_joint")

joints = [
    j1,
    j2,
    j3,
    j4,
    j5,
    j6
]

joint_names = [
    "shoulder_pan",
    "shoulder_lift",
    "elbow",
    "wrist_1",
    "wrist_2",
    "wrist_3"
]


# ============================================================
# AFTER-OPTIMIZATION PID
# ============================================================

# PSO result from the optimization run:
# P = 11.937726
# I = 0.0
# D = 0.5

OPTIMIZED_P = 11.937726
OPTIMIZED_I = 0.0
OPTIMIZED_D = 0.5

for joint in joints:

    joint.setControlPID(
        OPTIMIZED_P,
        OPTIMIZED_I,
        OPTIMIZED_D
    )

print("")
print("==============================================")
print("       AFTER-OPTIMIZATION PID")
print("==============================================")
print("P =", OPTIMIZED_P)
print("I =", OPTIMIZED_I)
print("D =", OPTIMIZED_D)
print("==============================================")



# ============================================================
# ENABLE JOINT SENSORS
# ============================================================

position_sensors = []

for joint in joints:

    sensor = joint.getPositionSensor()

    if sensor is not None:
        sensor.enable(timestep)

    position_sensors.append(sensor)

    # Enable torque feedback
    joint.enableTorqueFeedback(timestep)


# ============================================================
# APPLE
# ============================================================

apple_node = robot.getFromDef("APPLE1")

if apple_node is None:

    print("ERROR: APPLE1 was not found.")
    print("Make sure the apple has:")
    print("DEF APPLE1")

    raise SystemExit


apple_translation = apple_node.getField("translation")
apple_physics_field = apple_node.getField("physics")


# ============================================================
# REMOVE TREE COLLISION
# ============================================================

tree_node = robot.getFromDef("AppleTreeTrunk")

if tree_node is None:

    print(
        "WARNING: AppleTreeTrunk was not found."
    )


if tree_node is not None:

    physics_field = tree_node.getField(
        "boundingObject"
    )

    if physics_field is not None:

        try:

            physics_field.removeSF()

            print(
                "Tree collision removed."
            )

        except Exception as e:

            print(
                "Could not remove tree collision:",
                e
            )


# ============================================================
# CSV DATA LOGGING
# ============================================================

controller_folder = os.path.dirname(
    os.path.abspath(__file__)
)

csv_path = os.path.join(
    controller_folder,
    "after_optimization.csv"
)


csv_file = open(
    csv_path,
    "w",
    newline=""
)

csv_writer = csv.writer(
    csv_file
)


# ============================================================
# CSV HEADER
# ============================================================

header = [
    "time"
]


# Joint torque columns

for name in joint_names:

    header.append(
        name + "_torque_Nm"
    )


# Joint power columns

for name in joint_names:

    header.append(
        name + "_power_W"
    )


# Total power

header.append(
    "total_power_W"
)


# Vacuum pressure

header.append(
    "vacuum_pressure_kPa"
)


# Gripper state

header.append(
    "gripper_state"
)


csv_writer.writerow(
    header
)


# ============================================================
# POWER PARAMETERS
# ============================================================

# Webots motor consumption factor
CONSUMPTION_FACTOR = 10.0


# Energy consumed by each joint
energy_consumed = np.zeros(6)


previous_time = None


# ============================================================
# VACUUM PARAMETERS
# ============================================================

# Simulated vacuum pressure.
#
# This is NOT a physical pressure sensor.
#
# 0 kPa    = vacuum OFF
# -70 kPa  = vacuum holding apple

vacuum_pressure_kPa = 0.0

VACUUM_TARGET_KPA = -70.0


# ============================================================
# GRIPPER STATE
# ============================================================

gripper_state = "OPEN"


# ============================================================
# APPLE ATTACHMENT
# ============================================================

apple_attached = False


def disable_apple_physics():

    if apple_physics_field is None:
        return

    try:

        if apple_physics_field.getSFNode() is not None:

            apple_physics_field.removeSF()

            print("Apple physics disabled: apple is now attached kinematically.")

    except Exception as e:

        print("Could not remove apple physics:", e)


# ============================================================
# DATA LOGGING FUNCTION
# ============================================================

def log_data():

    global previous_time
    global energy_consumed

    # --------------------------------------------------------
    # Current simulation time
    # --------------------------------------------------------

    current_time = robot.getTime()


    # --------------------------------------------------------
    # Read torque from each joint
    # --------------------------------------------------------

    torques = []

    for joint in joints:

        try:

            torque = joint.getTorqueFeedback()

            # Make sure torque is a valid number
            if not math.isfinite(torque):
                torque = 0.0

        except Exception:

            torque = 0.0

        torques.append(
            float(torque)
        )


    # --------------------------------------------------------
    # Calculate power for every joint
    #
    # Power = |Torque| × Consumption Factor
    # --------------------------------------------------------

    powers = []

    for torque in torques:

        power = abs(torque) * CONSUMPTION_FACTOR

        if not math.isfinite(power):

            power = 0.0

        powers.append(
            float(power)
        )


    # --------------------------------------------------------
    # Calculate total power
    # --------------------------------------------------------

    total_power = 0.0

    for power in powers:

        if math.isfinite(power):

            total_power += power


    # --------------------------------------------------------
    # Calculate energy
    # --------------------------------------------------------

    if previous_time is not None:

        dt = current_time - previous_time

        if dt > 0:

            for i in range(6):

                energy_consumed[i] += (
                    powers[i] * dt
                )


    previous_time = current_time


    # --------------------------------------------------------
    # Create CSV row
    # --------------------------------------------------------

    row = [
        current_time
    ]


    # Torque values

    row.extend(
        torques
    )


    # Power values

    row.extend(
        powers
    )


    # Total power

    row.append(
        total_power
    )


    # Vacuum pressure

    row.append(
        vacuum_pressure_kPa
    )


    # Gripper state

    row.append(
        gripper_state
    )


    # --------------------------------------------------------
    # Console output
    # --------------------------------------------------------

    print(
        "Time:",
        round(current_time, 2),
        "| Total Power:",
        round(total_power, 3),
        "W",
        "| Vacuum:",
        round(vacuum_pressure_kPa, 2),
        "kPa",
        "| State:",
        gripper_state
    )


    # --------------------------------------------------------
    # Save to CSV
    # --------------------------------------------------------

    csv_writer.writerow(
        row
    )

    csv_file.flush()


# ============================================================
# WAIT FUNCTION
# ============================================================

def wait(seconds):

    end_time = (
        robot.getTime()
        + seconds
    )

    while robot.step(timestep) != -1:

        # Record measurements
        log_data()

        if robot.getTime() >= end_time:

            break


# ============================================================
# SET JOINT POSITIONS
# ============================================================

def set_joints(q):

    j1.setPosition(
        q[0]
    )

    j2.setPosition(
        q[1]
    )

    j3.setPosition(
        q[2]
    )

    j4.setPosition(
        q[3]
    )

    j5.setPosition(
        q[4]
    )

    j6.setPosition(
        q[5]
    )


# ============================================================
# ROTATION MATRIX - Z
# ============================================================

def Rz(angle):

    c = math.cos(angle)

    s = math.sin(angle)

    return np.array([
        [c, -s, 0.0],
        [s,  c, 0.0],
        [0.0, 0.0, 1.0]
    ])


# ============================================================
# ROTATION MATRIX - Y
# ============================================================

def Ry(angle):

    c = math.cos(angle)

    s = math.sin(angle)

    return np.array([
        [ c, 0.0, s],
        [0.0, 1.0, 0.0],
        [-s, 0.0, c]
    ])


# ============================================================
# FORWARD KINEMATICS
# ============================================================

def forward_kinematics(q):

    # UR5e base position
    p = np.array(
        [1.1, 0.4, 0.0],
        dtype=float
    )

    R = np.eye(3)


    # --------------------------------------------------------
    # Joint 1
    # --------------------------------------------------------

    p = p + R @ np.array([
        0.0,
        0.0,
        0.163
    ])

    R = R @ Rz(
        q[0]
    )


    # --------------------------------------------------------
    # Joint 2
    # --------------------------------------------------------

    p = p + R @ np.array([
        0.0,
        0.138,
        0.0
    ])

    R = (
        R
        @ Ry(q[1])
        @ Ry(math.pi / 2.0)
    )


    # --------------------------------------------------------
    # Joint 3
    # --------------------------------------------------------

    p = p + R @ np.array([
        0.0,
        -0.131,
        0.425
    ])

    R = R @ Ry(
        q[2]
    )


    # --------------------------------------------------------
    # Joint 4
    # --------------------------------------------------------

    p = p + R @ np.array([
        0.0,
        0.0,
        0.392
    ])

    R = (
        R
        @ Ry(q[3])
        @ Ry(math.pi / 2.0)
    )


    # --------------------------------------------------------
    # Joint 5
    # --------------------------------------------------------

    p = p + R @ np.array([
        0.0,
        0.127,
        0.0
    ])

    R = R @ Rz(
        q[4]
    )


    # --------------------------------------------------------
    # Joint 6
    # --------------------------------------------------------

    p = p + R @ np.array([
        0.0,
        0.0,
        0.1
    ])

    R = R @ Ry(
        q[5]
    )


    # --------------------------------------------------------
    # Tool
    # --------------------------------------------------------

    p = p + R @ np.array([
        0.0,
        0.1,
        0.0
    ])


    return p


# ============================================================
# SMOOTH ROBOT MOVEMENT
# ============================================================

def move_smooth(
        q_start,
        q_end,
        duration):

    global apple_attached

    q_start = np.array(
        q_start,
        dtype=float
    )

    q_end = np.array(
        q_end,
        dtype=float
    )


    start_time = robot.getTime()


    while robot.step(timestep) != -1:

        elapsed = (
            robot.getTime()
            - start_time
        )


        alpha = (
            elapsed
            / duration
        )


        if alpha > 1.0:

            alpha = 1.0


        if alpha < 0.0:

            alpha = 0.0


        # ----------------------------------------------------
        # Smoothstep interpolation
        # ----------------------------------------------------

        smooth_alpha = (
            alpha
            * alpha
            * (3.0 - 2.0 * alpha)
        )


        # ----------------------------------------------------
        # Calculate current joint configuration
        # ----------------------------------------------------

        q = (
            q_start
            + smooth_alpha
            * (q_end - q_start)
        )


        # ----------------------------------------------------
        # Move robot
        # ----------------------------------------------------

        set_joints(
            q
        )


        # ----------------------------------------------------
        # Move apple with end-effector
        # ----------------------------------------------------

        if apple_attached:

            tool_position = (
                forward_kinematics(q)
            )


            apple_translation.setSFVec3f([
                float(tool_position[0]),
                float(tool_position[1]),
                float(tool_position[2])
            ])


        # ----------------------------------------------------
        # Record measurements
        # ----------------------------------------------------

        log_data()


        if alpha >= 1.0:

            break


# ============================================================
# SET VACUUM PRESSURE
# ============================================================

def set_vacuum_pressure(
        pressure):

    global vacuum_pressure_kPa

    vacuum_pressure_kPa = (
        pressure
    )


# ============================================================
# RAMP VACUUM PRESSURE
# ============================================================

def ramp_vacuum_pressure(
        start_pressure,
        end_pressure,
        duration):

    global vacuum_pressure_kPa

    start_time = robot.getTime()


    while robot.step(timestep) != -1:

        elapsed = (
            robot.getTime()
            - start_time
        )


        alpha = (
            elapsed
            / duration
        )


        if alpha > 1.0:

            alpha = 1.0


        if alpha < 0.0:

            alpha = 0.0


        # ----------------------------------------------------
        # Smooth pressure transition
        # ----------------------------------------------------

        smooth_alpha = (
            alpha
            * alpha
            * (3.0 - 2.0 * alpha)
        )


        vacuum_pressure_kPa = (
            start_pressure
            + smooth_alpha
            * (
                end_pressure
                - start_pressure
            )
        )


        # ----------------------------------------------------
        # Record data
        # ----------------------------------------------------

        log_data()


        if alpha >= 1.0:

            break


# ============================================================
# JOINT CONFIGURATIONS
# ============================================================

q_home = [
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0
]


q_safe = [
    -0.59319229,
    -1.57281149,
    -0.10760306,
    -1.72169317,
    -1.52260647,
    -1.27575594
]


q_grasp = [
    -3.13156112,
    -2.45383496,
     0.95411500,
     2.83000653,
    -0.00017378,
     2.65902212
]


q_basket = [
     2.23183496,
    -0.92391970,
     1.48778129,
    -1.39135520,
     0.34704539,
     0.0
]


# ============================================================
# MOVEMENT TIME
# ============================================================

MOVE_TIME = 3.0


# ============================================================
# START MESSAGE
# ============================================================

print("")
print("==============================================")
print("       FRUIT HARVESTING ROBOT")
print("==============================================")
print("")

print(
    "Power and vacuum-pressure logging enabled."
)

print("")

print(
    "CSV file:"
)

print(
    csv_path
)

print("")


# ============================================================
# STEP 1 - HOME
# ============================================================

print("STEP 1: HOME")

gripper_state = "OPEN"

set_vacuum_pressure(
    0.0
)

set_joints(
    q_home
)

wait(
    2.0
)


# ============================================================
# STEP 2 - SAFE POSITION
# ============================================================

print(
    "STEP 2: MOVING TO SAFE POSITION"
)

move_smooth(
    q_home,
    q_safe,
    MOVE_TIME
)

wait(
    1.0
)


# ============================================================
# STEP 3 - APPROACH APPLE
# ============================================================

print(
    "STEP 3: APPROACHING APPLE"
)

move_smooth(
    q_safe,
    q_grasp,
    MOVE_TIME
)

wait(
    1.0
)


# ------------------------------------------------------------
# End-effector position
# ------------------------------------------------------------

tool = forward_kinematics(
    q_grasp
)


print(
    "End-effector:"
)

print(
    round(tool[0], 3),
    round(tool[1], 3),
    round(tool[2], 3)
)


# ============================================================
# STEP 4 - GRASP APPLE
# ============================================================

print(
    "STEP 4: GRASPING APPLE"
)


gripper_state = (
    "VACUUM_BUILDUP"
)


# ------------------------------------------------------------
# Build vacuum
# ------------------------------------------------------------

ramp_vacuum_pressure(
    0.0,
    VACUUM_TARGET_KPA,
    1.0
)


# ------------------------------------------------------------
# Attach apple
# ------------------------------------------------------------

# Disable the apple's physics before attaching it.
# This prevents gravity/collision physics from fighting the
# controller while the apple is being carried.
disable_apple_physics()

apple_attached = True


apple_translation.setSFVec3f([
    float(tool[0]),
    float(tool[1]),
    float(tool[2])
])


gripper_state = (
    "GRASPED"
)


wait(
    2.0
)


print(
    "APPLE ATTACHED"
)

print(
    "Vacuum pressure:",
    VACUUM_TARGET_KPA,
    "kPa"
)


# ============================================================
# STEP 5 - RETRACT WITH APPLE
# ============================================================

print(
    "STEP 5: RETRACTING WITH APPLE"
)


gripper_state = (
    "HOLDING"
)


move_smooth(
    q_grasp,
    q_safe,
    MOVE_TIME
)


wait(
    1.0
)


# ============================================================
# STEP 6 - MOVE TO BASKET
# ============================================================

print(
    "STEP 6: MOVING TO HARVEST BASKET"
)


gripper_state = (
    "HOLDING"
)


move_smooth(
    q_safe,
    q_basket,
    MOVE_TIME
)


wait(
    1.0
)


# ============================================================
# STEP 7 - RELEASE APPLE
# ============================================================

print(
    "STEP 7: RELEASING APPLE"
)


gripper_state = (
    "RELEASING"
)


# ------------------------------------------------------------
# Release vacuum
# ------------------------------------------------------------

ramp_vacuum_pressure(
    VACUUM_TARGET_KPA,
    0.0,
    1.0
)


# ------------------------------------------------------------
# Release apple into basket
# ------------------------------------------------------------

apple_translation.setSFVec3f([
    0.5,
    0.8,
    0.25
])


apple_attached = False


gripper_state = (
    "RELEASED"
)


wait(
    2.0
)


print(
    "APPLE RELEASED INTO BASKET"
)


# ============================================================
# STEP 8 - RETURN HOME
# ============================================================

print(
    "STEP 8: RETURNING HOME"
)


gripper_state = (
    "OPEN"
)


move_smooth(
    q_basket,
    q_home,
    MOVE_TIME
)


wait(
    2.0
)


# ============================================================
# CLOSE CSV FILE
# ============================================================

csv_file.close()


# ============================================================
# ENERGY SUMMARY
# ============================================================

print("")
print("==============================================")
print("         HARVESTING COMPLETE")
print("==============================================")
print("")

print(
    "Apple picked successfully."
)

print(
    "Apple transported to basket."
)

print(
    "Apple released."
)

print(
    "Robot returned home."
)

print("")


# ============================================================
# ENERGY CONSUMPTION
# ============================================================

print(
    "=============================================="
)

print(
    "       JOINT ENERGY CONSUMPTION"
)

print(
    "=============================================="
)


for i in range(6):

    print(
        joint_names[i],
        ":",
        round(
            energy_consumed[i],
            3
        ),
        "J"
    )


print("")


# ============================================================
# TOTAL ENERGY
# ============================================================

total_energy = sum(
    energy_consumed
)


print(
    "Total joint energy:",
    round(
        total_energy,
        3
    ),
    "J"
)


print("")


# ============================================================
# CSV LOCATION
# ============================================================

print(
    "Measurement file saved to:"
)

print(
    csv_path
)

print("")


# ============================================================
# KEEP SIMULATION RUNNING
# ============================================================
#
# IMPORTANT:
# The CSV has already been closed.
# Therefore we DO NOT call log_data() here.
#

while robot.step(timestep) != -1:

    pass