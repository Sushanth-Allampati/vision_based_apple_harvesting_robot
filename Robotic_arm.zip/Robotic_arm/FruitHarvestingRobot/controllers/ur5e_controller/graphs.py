import pandas as pd
import matplotlib.pyplot as plt
import os


# ============================================================
# FILE LOCATION
# ============================================================

folder = os.path.dirname(
    os.path.abspath(__file__)
)

csv_file = os.path.join(
    folder,
    "harvesting_data.csv"
)


# ============================================================
# READ CSV
# ============================================================

data = pd.read_csv(csv_file)

print("")
print("==============================================")
print("CSV DATA CHECK")
print("==============================================")

print("Rows:", len(data))
print("Columns:")
print(data.columns.tolist())

print("")
print("First 5 rows:")
print(data.head())


# ============================================================
# CONVERT NUMERIC COLUMNS
# ============================================================

numeric_columns = [
    "time",

    "shoulder_pan_power_W",
    "shoulder_lift_power_W",
    "elbow_power_W",
    "wrist_1_power_W",
    "wrist_2_power_W",
    "wrist_3_power_W",

    "total_power_W",

    "vacuum_pressure_kPa"
]

for column in numeric_columns:

    if column in data.columns:

        data[column] = pd.to_numeric(
            data[column],
            errors="coerce"
        )


# ============================================================
# REMOVE INVALID TOTAL POWER VALUES
# ============================================================

valid_data = data.dropna(
    subset=[
        "time",
        "total_power_W"
    ]
)


print("")
print("Valid total-power rows:",
      len(valid_data))

print("")
print("Total power values:")

print(
    valid_data[
        ["time", "total_power_W"]
    ].head(20)
)


# ============================================================
# GRAPH 1
# JOINT POWER
# ============================================================

plt.figure(figsize=(12, 6))

plt.plot(
    data["time"],
    data["shoulder_pan_power_W"],
    label="Shoulder Pan"
)

plt.plot(
    data["time"],
    data["shoulder_lift_power_W"],
    label="Shoulder Lift"
)

plt.plot(
    data["time"],
    data["elbow_power_W"],
    label="Elbow"
)

plt.plot(
    data["time"],
    data["wrist_1_power_W"],
    label="Wrist 1"
)

plt.plot(
    data["time"],
    data["wrist_2_power_W"],
    label="Wrist 2"
)

plt.plot(
    data["time"],
    data["wrist_3_power_W"],
    label="Wrist 3"
)

plt.xlabel("Time (s)")
plt.ylabel("Power (W)")

plt.title(
    "UR5e Joint Power Consumption During Apple Harvesting"
)

plt.legend()
plt.grid(True)

plt.tight_layout()

plt.savefig(
    os.path.join(
        folder,
        "joint_power_consumption.png"
    ),
    dpi=300
)

plt.show()


# ============================================================
# GRAPH 2
# TOTAL POWER
# ============================================================

plt.figure(figsize=(12, 6))

plt.plot(
    valid_data["time"],
    valid_data["total_power_W"],
    linewidth=2,
    label="Total UR5e Power"
)

plt.xlabel("Time (s)")
plt.ylabel("Total Power (W)")

plt.title(
    "Total UR5e Power Consumption During Apple Harvesting"
)

plt.legend()
plt.grid(True)

plt.tight_layout()

plt.savefig(
    os.path.join(
        folder,
        "total_power_consumption.png"
    ),
    dpi=300
)

plt.show()


# ============================================================
# GRAPH 3
# VACUUM PRESSURE
# ============================================================

plt.figure(figsize=(12, 5))

plt.plot(
    data["time"],
    data["vacuum_pressure_kPa"],
    linewidth=2,
    label="Vacuum Pressure"
)

plt.xlabel("Time (s)")
plt.ylabel("Vacuum Pressure (kPa)")

plt.title(
    "Simulated Vacuum Pressure During Apple Handling"
)

plt.legend()
plt.grid(True)

plt.tight_layout()

plt.savefig(
    os.path.join(
        folder,
        "vacuum_pressure.png"
    ),
    dpi=300
)

plt.show()


# ============================================================
# FINISHED
# ============================================================

print("")
print("==============================================")
print("GRAPHS GENERATED")
print("==============================================")

print("")
print("Joint power graph:")
print(
    os.path.join(
        folder,
        "joint_power_consumption.png"
    )
)

print("")
print("Total power graph:")
print(
    os.path.join(
        folder,
        "total_power_consumption.png"
    )
)

print("")
print("Vacuum pressure graph:")
print(
    os.path.join(
        folder,
        "vacuum_pressure.png"
    )
)