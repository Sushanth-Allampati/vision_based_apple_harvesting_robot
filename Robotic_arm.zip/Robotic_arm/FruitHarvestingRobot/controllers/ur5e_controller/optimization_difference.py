import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os


# ============================================================
# 1. FIND THE CSV FILES
# ============================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

BEFORE_FILE = os.path.join(
    SCRIPT_DIR,
    "before_optimization.csv"
)

AFTER_FILE = os.path.join(
    SCRIPT_DIR,
    "after_optimization.csv"
)


# ============================================================
# 2. CHECK FILES
# ============================================================

print("=" * 70)
print("PID OPTIMIZATION - BEFORE vs AFTER COMPARISON")
print("=" * 70)

print("\nScript folder:")
print(SCRIPT_DIR)

print("\nBefore CSV:")
print(BEFORE_FILE)

print("\nAfter CSV:")
print(AFTER_FILE)


if not os.path.exists(BEFORE_FILE):
    print("\nERROR:")
    print("before_optimization.csv was not found.")
    print("Expected location:")
    print(BEFORE_FILE)
    exit()

if not os.path.exists(AFTER_FILE):
    print("\nERROR:")
    print("after_optimization.csv was not found.")
    print("Expected location:")
    print(AFTER_FILE)
    exit()

print("\nBoth CSV files were found!")


# ============================================================
# 3. LOAD CSV FILES
# ============================================================

print("\nLoading CSV files...")

before = pd.read_csv(BEFORE_FILE)
after = pd.read_csv(AFTER_FILE)

print("CSV files loaded successfully!")


# ============================================================
# 4. SHOW COLUMN NAMES
# ============================================================

print("\n" + "=" * 70)
print("COLUMNS IN BEFORE CSV")
print("=" * 70)

for i, column in enumerate(before.columns):
    print(f"{i + 1}. {column}")


print("\n" + "=" * 70)
print("COLUMNS IN AFTER CSV")
print("=" * 70)

for i, column in enumerate(after.columns):
    print(f"{i + 1}. {column}")


# ============================================================
# 5. CHECK REQUIRED TIME COLUMN
# ============================================================

if "time" not in before.columns:
    print("\nERROR: 'time' column is missing from before_optimization.csv")
    exit()

if "time" not in after.columns:
    print("\nERROR: 'time' column is missing from after_optimization.csv")
    exit()


# ============================================================
# 6. FIND TOTAL POWER COLUMN
# ============================================================

def find_total_power_column(dataframe):

    # First look for the expected name
    if "total_power_W" in dataframe.columns:
        return "total_power_W"

    # Otherwise search automatically
    for column in dataframe.columns:

        name = column.lower().replace(" ", "_")

        if "total" in name and "power" in name:
            return column

    return None


before_total_power_column = find_total_power_column(before)
after_total_power_column = find_total_power_column(after)


print("\n" + "=" * 70)
print("TOTAL POWER COLUMN")
print("=" * 70)

print(
    "Before:",
    before_total_power_column
)

print(
    "After :",
    after_total_power_column
)


# ============================================================
# 7. FIND INDIVIDUAL JOINT POWER COLUMNS
# ============================================================

def find_joint_power_columns(dataframe):

    possible_columns = []

    for column in dataframe.columns:

        name = column.lower()

        # Must contain "power"
        if "power" not in name:
            continue

        # Ignore total power
        if "total" in name:
            continue

        possible_columns.append(column)

    return possible_columns


before_joint_power_columns = find_joint_power_columns(before)
after_joint_power_columns = find_joint_power_columns(after)


print("\n" + "=" * 70)
print("INDIVIDUAL JOINT POWER COLUMNS")
print("=" * 70)

print("\nAfter optimization:")

if before_joint_power_columns:

    for column in before_joint_power_columns:
        print("  ", column)

else:

    print("   No individual power columns found.")


print("\nBefore optimization:")

if after_joint_power_columns:

    for column in after_joint_power_columns:
        print("  ", column)

else:

    print("   No individual power columns found.")


# ============================================================
# 8. CALCULATE TOTAL POWER IF NECESSARY
# ============================================================

def calculate_total_power(dataframe, total_column):

    if total_column is not None:

        return dataframe[total_column].astype(float)

    # If total power doesn't exist,
    # calculate it from individual power columns.

    joint_columns = find_joint_power_columns(dataframe)

    if len(joint_columns) == 0:

        raise ValueError(
            "No total power or individual joint power columns found."
        )

    print(
        "\nTotal power column not found."
        "\nCalculating total power from joint power columns..."
    )

    return dataframe[joint_columns].sum(axis=1)


before_total_power = calculate_total_power(
    before,
    before_total_power_column
)

after_total_power = calculate_total_power(
    after,
    after_total_power_column
)


# ============================================================
# 9. BASIC PERFORMANCE VALUES
# ============================================================

before_time = before["time"].astype(float)
after_time = after["time"].astype(float)


before_duration = (
    before_time.iloc[-1]
    - before_time.iloc[0]
)

after_duration = (
    after_time.iloc[-1]
    - after_time.iloc[0]
)


before_average_power = before_total_power.mean()
after_average_power = after_total_power.mean()


before_peak_power = before_total_power.max()
after_peak_power = after_total_power.max()


# ============================================================
# 10. TOTAL ENERGY
# ============================================================

before_energy = np.trapezoid(
    before_total_power,
    before_time
)

after_energy = np.trapezoid(
    after_total_power,
    after_time
)


# ============================================================
# 11. CALCULATE PERCENTAGE CHANGES
# ============================================================

if before_energy != 0:

    energy_change = (
        (before_energy - after_energy)
        / before_energy
    ) * 100

else:

    energy_change = 0


if before_average_power != 0:

    average_power_change = (
        (before_average_power - after_average_power)
        / before_average_power
    ) * 100

else:

    average_power_change = 0


if before_peak_power != 0:

    peak_power_change = (
        (before_peak_power - after_peak_power)
        / before_peak_power
    ) * 100

else:

    peak_power_change = 0


# ============================================================
# 12. DISPLAY RESULTS
# ============================================================

print("\n" + "=" * 70)
print("RESULTS")
print("=" * 70)

print("\n After OPTIMIZATION")
print("-" * 40)

print(
    f"Duration       : {before_duration:.4f} s"
)

print(
    f"Average Power  : {before_average_power:.4f} W"
)

print(
    f"Peak Power     : {before_peak_power:.4f} W"
)

print(
    f"Total Energy   : {before_energy:.4f} J"
)


print("\n Before OPTIMIZATION")
print("-" * 40)

print(
    f"Duration       : {after_duration:.4f} s"
)

print(
    f"Average Power  : {after_average_power:.4f} W"
)

print(
    f"Peak Power     : {after_peak_power:.4f} W"
)

print(
    f"Total Energy   : {after_energy:.4f} J"
)


print("\nCHANGE AFTER OPTIMIZATION")
print("-" * 40)

print(
    f"Energy Change       : {energy_change:.2f}%"
)

print(
    f"Average Power Change: {average_power_change:.2f}%"
)

print(
    f"Peak Power Change   : {peak_power_change:.2f}%"
)


# ============================================================
# 13. GRAPH 1 - TOTAL POWER VS TIME
# ============================================================

plt.figure(figsize=(11, 6))

plt.plot(
    before_time,
    before_total_power,
    label="After Optimization"
)

plt.plot(
    after_time,
    after_total_power,
    label="Before Optimization"
)

plt.xlabel("Time (s)")
plt.ylabel("Total Power (W)")

plt.title(
    "Total Power Before vs After PID Optimization"
)

plt.legend()

plt.grid(True)

plt.tight_layout()

power_graph = os.path.join(
    SCRIPT_DIR,
    "power_comparison.png"
)

plt.savefig(
    power_graph,
    dpi=300
)

plt.show()


# ============================================================
# 14. GRAPH 2 - JOINT POWER COMPARISON
# ============================================================

# We need to compare corresponding joint columns.
#
# Instead of assuming their exact names,
# we identify them based on their position.

joint_names = [
    "Shoulder Pan",
    "Shoulder Lift",
    "Elbow",
    "Wrist 1",
    "Wrist 2",
    "Wrist 3"
]


# Use only columns present in BOTH CSV files

common_power_columns = []

for before_column in before_joint_power_columns:

    if before_column in after.columns:

        common_power_columns.append(
            before_column
        )


print("\n" + "=" * 70)
print("COMMON JOINT POWER COLUMNS")
print("=" * 70)

for column in common_power_columns:

    print("  ", column)


if len(common_power_columns) > 0:

    before_joint_average = []
    after_joint_average = []
    displayed_joint_names = []


    for i, column in enumerate(common_power_columns):

        before_average = before[column].astype(float).mean()

        after_average = after[column].astype(float).mean()

        before_joint_average.append(
            before_average
        )

        after_joint_average.append(
            after_average
        )


        if i < len(joint_names):

            displayed_joint_names.append(
                joint_names[i]
            )

        else:

            displayed_joint_names.append(
                column
            )


    # Create graph

    x = np.arange(
        len(displayed_joint_names)
    )

    width = 0.35


    plt.figure(
        figsize=(11, 6)
    )


    plt.bar(
        x - width / 2,
        before_joint_average,
        width,
        label="After Optimization"
    )


    plt.bar(
        x + width / 2,
        after_joint_average,
        width,
        label="Before Optimization"
    )


    plt.xlabel(
        "Robot Joint"
    )

    plt.ylabel(
        "Average Power (W)"
    )

    plt.title(
        "Joint Power Comparison"
    )


    plt.xticks(
        x,
        displayed_joint_names,
        rotation=20
    )


    plt.legend()

    plt.grid(
        axis="y"
    )


    plt.tight_layout()


    joint_graph = os.path.join(
        SCRIPT_DIR,
        "joint_power_comparison.png"
    )


    plt.savefig(
        joint_graph,
        dpi=300
    )


    plt.show()


else:

    print(
        "\nNo common individual joint-power columns were found."
    )

    print(
        "Skipping joint-power graph."
    )


# ============================================================
# 15. GRAPH 3 - TOTAL ENERGY
# ============================================================

plt.figure(
    figsize=(8, 6)
)


plt.bar(
    [
        "After Optimization",
        "Before Optimization"
    ],
    [
        before_energy,
        after_energy
    ]
)


plt.ylabel(
    "Energy (J)"
)

plt.title(
    "Total Energy Consumption"
)


plt.grid(
    axis="y"
)


plt.tight_layout()


energy_graph = os.path.join(
    SCRIPT_DIR,
    "energy_comparison.png"
)


plt.savefig(
    energy_graph,
    dpi=300
)


plt.show()


# ============================================================
# 16. CREATE SUMMARY CSV
# ============================================================

summary = pd.DataFrame({

    "Metric": [

        "Duration (s)",

        "Average Power (W)",

        "Peak Power (W)",

        "Total Energy (J)"

    ],

    "After Optimization": [

        before_duration,

        before_average_power,

        before_peak_power,

        before_energy

    ],

    "Before Optimization": [

        after_duration,

        after_average_power,

        after_peak_power,

        after_energy

    ]

})


summary_file = os.path.join(
    SCRIPT_DIR,
    "comparison_summary.csv"
)


summary.to_csv(
    summary_file,
    index=False
)


# ============================================================
# 17. FINAL MESSAGE
# ============================================================

print("\n" + "=" * 70)
print("COMPARISON COMPLETE")
print("=" * 70)

print("\nGenerated files:")

print(
    "\n1. power_comparison.png"
)

print(
    "2. joint_power_comparison.png"
)

print(
    "3. energy_comparison.png"
)

print(
    "4. comparison_summary.csv"
)

print("\nAll files were saved in:")

print(SCRIPT_DIR)

print("\nDone!")